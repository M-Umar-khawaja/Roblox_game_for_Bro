# BLOCKFIRE: Game Design Document

**Genre:** Fast arena first-person shooter for Roblox (PC, mobile, console)
**Map shipped in v1:** *Dockyard*, a container terminal at sunset
**Players per server:** 12 recommended (works from 1 to 20). AI bots fill empty slots.
**Version:** 1.0

---

## 1. Research summary: what the top Roblox shooters do well

| Game | What players love | What Blockfire takes from it |
|---|---|---|
| **RIVALS** (biggest Roblox FPS of 2025–26, ~280K concurrent at peak) | Snappy controls, **slide + slide-jump movement**, clean arena maps, loadout = primary + secondary + melee + utility, rotating modes, Gun Game | Slide/slide-jump movement, 4-slot loadout, Gun Game, quick matches |
| **Arsenal** | Gun Game ladder (one weapon per kill, finish with the knife), chaotic fun, fast respawns | Gun Game mode with knife finale and knife "demote" |
| **Phantom Forces** | Weapon progression, unlocks by level, ADS feel, TDM / Domination modes | XP levels, weapon unlocks, Domination (A/B/C flags) |
| **[FPS] Flick** | Pure aim duels, no pay-to-win, instant action | Hitscan shooting with clear hit markers, no paid advantages |
| **Counter Blox / Bad Business** | Tactical maps with lanes, recoil control | Three-lane map design, learnable recoil |

**Lessons we applied:**
1. **Controls are king.** Instant client-side hit feedback, smooth ADS, low input lag, clean recoil that the player can learn.
2. **Get into action in seconds.** PLAY, then deploy, then fight. Respawn in 3 seconds. Bots mean there is always someone to fight, even in an empty server.
3. **Progression without pay-to-win.** Levels unlock *different* weapons, not better ones. Camos are earned with weapon kills.
4. **Readable maps.** Three lanes, clear spawns, mixed sightlines (close, mid and long), and objectives in the middle.
5. **Every platform.** Mouse and keyboard, touch buttons and gamepad.

---

## 2. Core loop

```
Join → Title screen (PLAY) → Pick loadout → DEPLOY
   → Fight (kills, objectives, streaks) → Die → Kill-cam info → 3 s → DEPLOY again
   → Match ends → Results + XP + vote next mode → New match (about 15 s later)
```

* **Match length:** 7–10 minutes, depending on mode.
* **XP** goes into account level and unlocks. All progress saves automatically through DataStore.

---

## 3. Game modes (voted at the end of every match)

| Mode | Teams | Win condition | Time limit |
|---|---|---|---|
| **Team Deathmatch (TDM)** | Blue vs Red | First team to **40 kills** | 8 min |
| **Domination (DOM)** | Blue vs Red | Hold flags **A / B / C**. Each held flag earns 1 point every 2 s. First to **150** wins. | 10 min |
| **Free For All (FFA)** | Everyone vs everyone | First player to **20 kills** | 7 min |
| **Gun Game (GG)** | Everyone vs everyone | Go through the **10-weapon ladder**. Each kill gives you the next gun. The last weapon is the knife. A knife kill demotes the victim by one. | 10 min |

If the time runs out, the team or player with the highest score wins.

**Domination capture rules:**
* Standing in a zone moves its capture meter toward your team. Capturing a neutral flag takes 5 s alone, 3.3 s with two players, and 2.5 s with three or more.
* An enemy flag must first be **neutralized** (the meter goes to 0) and then captured.
* If both teams stand in a zone, it is **contested** and the meter freezes.
* A capture gives +150 XP to everyone in the zone.

**Gun Game ladder:** Sidewinder Pistol → Hand Cannon → Wasp → Hornet SMG → Vanguard AR → Trident Burst → Breacher Shotgun → Sentinel DMR → Longbow Sniper → **Combat Knife**

---

## 4. Weapons

Every gun is built from Roblox parts in code, so there are no outside models to break. Each gun has its own model, sound and handling.

| Slot | Weapon | Class | Fire mode | Damage (close→far) | RPM | Mag | Unlock |
|---|---|---|---|---|---|---|---|
| Primary | **Vanguard** | Assault rifle | Auto | 26 → 19 | 640 | 30 | Lv 1 |
| Primary | **Hornet** | SMG | Auto | 22 → 13 | 850 | 32 | Lv 1 |
| Primary | **Breacher** | Shotgun | Pump, 8 pellets | 16×8 → 4×8 | 75 | 6 | Lv 2 |
| Primary | **Sentinel** | Marksman (DMR) | Semi | 42 → 36 | 300 | 15 | Lv 4 |
| Primary | **Longbow** | Sniper | Bolt | 95 (head ×2.5) | 45 | 5 | Lv 6 |
| Primary | **Trident** | Burst rifle | 3-round burst | 30 → 22 | 900 burst | 24 | Lv 10 |
| Primary | **Bulwark** | LMG | Auto | 27 → 21 | 700 | 80 | Lv 15 |
| Secondary | **Sidewinder** | Pistol | Semi | 24 → 16 | 420 | 12 | Lv 1 |
| Secondary | **Wasp** | Machine pistol | Auto | 17 → 10 | 1000 | 20 | Lv 8 |
| Secondary | **Hand Cannon** | Revolver | Semi | 55 → 40 | 140 | 6 | Lv 12 |
| Melee | **Combat Knife** | Knife | Slash | 55, **backstab 100** | 120 | – | Lv 1 |
| Utility | **Frag Grenade** | Grenade | Throw (G) | up to 120 (radius 18) | – | 1 per life | Lv 1 |

**Damage multipliers:** Head ×1.4–2.5 (varies by gun), torso ×1.0, limbs ×0.85.
**Health:** 100. Health regenerates at 20 HP/s after 5 s without taking damage.

**Shooting model (what makes it feel good):**
* **Hitscan with prediction.** The shooter's client ray-casts instantly, so tracers, impacts and hit markers appear on the same frame. The server then **re-validates** each hit (fire rate, ammo, distance, line of sight, target position) before it applies any damage.
* **Spread:** hip-fire cone, a tight cone when aiming down sights, and penalties for moving and jumping. Crouching gives a bonus. Bloom builds per shot and recovers.
* **Recoil:** a learnable vertical kick with a small random horizontal drift. Part of it recovers automatically, so you pull down to stay on target. ADS reduces recoil by 30%.
* **ADS:** a smooth zoom with sights aligned to the screen centre. Snipers and the DMR show a scope overlay. ADS sensitivity is set separately.
* **Viewmodel:** first-person arms and gun with sway, walk bob, sprint pose, procedural reload/pump/bolt animations, an equip animation, recoil kick and a wall tuck (the gun pulls back near walls).
* **Feedback:** hit marker (white), kill marker (red), headshot (gold) and sounds for each. Optional damage numbers. Red damage-direction arcs, a low-health vignette and a kill feed.

**Camos (cosmetic):** earned per weapon by kills with that weapon: Factory (0), Woodland (10), Desert (25), Arctic (50), Crimson (100), Gold (200), Neon (400).

---

## 5. Movement

| Action | PC | Gamepad | Mobile |
|---|---|---|---|
| Move / Look | WASD / Mouse | Left / Right stick | Thumbstick / Drag |
| Fire | Left mouse | RT | **FIRE** button (drag it to aim while firing) |
| Aim (ADS) | Right mouse (hold or toggle) | LT | **AIM** button |
| Reload | R | X | **R** button |
| Sprint | Left Shift | L3 | **SPRINT** toggle |
| Crouch / **Slide** | C or Left Ctrl | B | **CROUCH** button |
| Jump | Space | A | Jump button |
| Weapons | 1 / 2 / 3, mouse wheel, Q = last weapon | Y = cycle | **SWAP** button |
| Grenade | G | RB | **NADE** button |
| Quick knife | V or F | R3 | **KNIFE** button |
| Scoreboard | Tab (hold) | D-pad down (hold) | **SCORE** button |
| Menu (loadout / settings) | M | – | ☰ button |

* Walk 18 · Sprint 26 · Crouch 9 · ADS ×0.65 (each weapon also has a mobility multiplier).
* **Slide:** sprint, then crouch, to burst forward at 42 speed. The slide fades out over 0.75 s and has a 0.9 s cooldown. Jumping during a slide keeps your momentum (**slide-jump**).
* Crouch lowers the camera and your real hitbox: the server poses the character's legs so everyone sees you crouch.

---

## 6. Progression and data

* **XP:** kill +100, headshot bonus +25, assist +50, capture +150, Gun Game level +50, killstreak bonus +50 per streak step, match finished +200, **win +500**.
* **Levels:** level *L* needs `1000 + 150·(L−1)` XP to reach *L*+1 (max 100). The first unlock arrives in your first match.
* **Saved data** (DataStore `BlockfireData_v1`): XP, level, totals (kills, deaths, wins, matches), kills per weapon, loadout, camos and settings. The game saves on leave, every 2 minutes and when the server shuts down. If saving is unavailable (for example in Studio without API access), the game still works and just doesn't save.

**Killstreak:** every 3 kills in one life gives **RECON SWEEP**: your team sees all enemies highlighted through walls for 5 s.

---

## 7. AI bots

Bots keep the game fun on day one when the servers are empty.
* `GameConfig.Bots.FillTo = 10`: bots fill up to 10 fighters in total and leave as real players join, so teams stay balanced.
* Bots navigate with **PathfindingService**, roam toward the action or flags, spot enemies with line-of-sight checks, react with a human-like delay, strafe, fire in bursts with distance-based inaccuracy, reload, and chase your last known position.
* They use the same weapon stats and the same damage pipeline as players, with a slight damage nerf (×0.8). In Gun Game they follow the ladder and use the knife at the end.
* Bots appear on the scoreboard and in the kill feed with a **BOT** tag.

---

## 8. Map: DOCKYARD

A container terminal on the waterfront at sunset. The map is **point-symmetric** (rotated 180° around the centre), so both teams get exactly the same layout.

```
            NORTH QUAY (long sniper lane along the water, broken by cover)
  Z=+86 ┌─────────────────────────────────────────────────────────────────────┐
        │ B │  BLUE CONTAINER YARD        │  open   │   RED WAREHOUSE       │ R │
        │ L │  (stacked containers,       │ loading │   (mezzanine, racks)  │ E │
        │ U │   ladders, maze aisles)     │  area   │                       │ D │
  Z=+46 │ E ├─────────────────────────────┴────╥────┴───────────────────────┤   │
        │   │   guard     (A)        container ║ CRANE    container   (C)   │ S │
        │ S │   booth   flag A                 ║  (B)                flag C │ P │
        │ P │                       container  ║ CRANE  container           │ A │
  Z=-46 │ A ├─────────────────────────────┬────╨────┬───────────────────────┤ W │
        │ W │   BLUE WAREHOUSE            │  open   │  RED CONTAINER YARD   │ N │
        │ N │   (mezzanine, racks)        │ loading │  (stacked containers) │   │
  Z=-86 └─────────────────────────────────────────────────────────────────────┘
            SOUTH QUAY (flank route behind the warehouse)
      X=-118                               X=0                            X=+118
```

**Key areas**
* **Spawns (both ends):** covered spawn shelter, 12-stud blast walls (with invisible caps so nobody can stand on them), a wide line-of-sight blocker in front of the middle exit, and three exits (north / middle / south). The automated map check proves that no spawn point can be seen from the middle, from the crane catwalks, from climbable container tops or from the enemy spawn.
* **Warehouse (CQB):** a 66 × 32 stud building with roller doors, window gaps facing mid, storage racks, a forklift, and a **mezzanine** (stairs up to Y 11) that overlooks the floor.
* **Container yard (mid range):** three rows of containers, some stacked two high. Ladders lead to elevated perches, and the aisles make a maze for flanking.
* **Middle (A / B / C):** A guard booth near A. The centre has a **giant gantry crane** with a suspended container and maintenance catwalks (ladder access, Y 12) that overlook flag B. Pinwheel container cover sits around B.
* **Quays:** narrow waterfront lanes on the north and south edges. Long sightlines are broken by crate stacks so they never reach spawn.
* **Backdrop:** terrain water, a docked cargo ship, distant cranes and a city skyline. Future lighting with a warm sunset, atmosphere haze, bloom and floodlights.

**Markers inside `Workspace.Map`:** `Spawns` (Team = Blue / Red / FFA), `Objectives` (A, B, C zones), `BotNodes` (roaming points), `Barriers` (invisible boundary walls).

---

## 9. User interface

* **Title / deploy screen:** logo, PLAY / DEPLOY, current mode and map, level and XP bar, loadout picker (weapon cards with stat bars and lock levels), camo picker, settings.
* **HUD:**
  * Health bar.
  * Ammo counter, weapon name and slot strip.
  * Dynamic crosshair.
  * Hit markers.
  * Kill feed.
  * Match bar with timer and scores, plus A/B/C flag status in DOM.
  * Radar: teammates, enemies who just fired, and flags.
  * XP pop-ups and streak banners.
  * Damage arcs.
  * Spawn-protection tag.
  * Enemy name on hover.
  * Scope overlay.
* **Scoreboard (Tab):** both teams with kills, deaths, assists, score and ping. Bots are tagged.
* **Death screen:** who killed you, with what weapon, from how far, and the killer's remaining HP. The camera looks at the killer.
* **End of match:** VICTORY / DEFEAT, top 3, your XP breakdown, and a vote for the next mode with live counts.
* **Settings (saved):** mouse sensitivity, ADS sensitivity, field of view, hold/toggle aim, crosshair colour and damage numbers.

---

## 10. Technical architecture

```
ReplicatedStorage/Blockfire        shared code
  Config/   GameConfig, Weapons, Modes, Progression, Sounds
  Modules/  Net, Signal, Spring, Util, Ballistics, WeaponModels, Viewmodel math
ServerScriptService/BlockfireServer
  Main (Script) → Services/
     Combatants  DataService  TeamService  MapService  SpawnService
     CombatService  WeaponService  ProjectileService  PoseService
     MatchService  BotService
  Modes/  TeamDeathmatch  Domination  FreeForAll  GunGame
StarterPlayerScripts/BlockfireClient
  Main (LocalScript) → Controllers/
     Input  Camera  Movement  Weapons  Viewmodel  Effects  Sound
     HUD  Menu  Scoreboard  MatchUI  NameTags  Radar  Mobile
Workspace/Map                      Dockyard (generated, editable in Studio)
```

**Networking**
* Remote events are created by the server under `ReplicatedStorage.Remotes`.
* Cosmetic shot effects use **UnreliableRemoteEvent** for low latency.
* Match state, scores and flags replicate through **attributes**, so clients redraw automatically:
  * `ReplicatedStorage.MatchState` holds the match state.
  * `ReplicatedStorage.Scoreboard/<id>` holds each fighter's score.
  * Each objective part holds its own flag state.

**Server authority and anti-cheat**
* Health, damage, ammo, reloads, grenades, kills, XP and spawning are all decided by the server.
* Each shot is checked on the server:
  * Fire-rate token bucket.
  * Ammo count and reload timer.
  * Shot origin must be near the head.
  * Pellet count.
  * Range.
  * Hit position must be near the target.
  * Line-of-sight ray.
  * Target must be an alive enemy without spawn protection.
* Knife hits are checked for distance and line of sight. The server simulates grenades.
* Remotes are rate-limited, and payload types are checked.

**Servers:** Roblox hosts all servers **for free** and starts new ones automatically as players join. There is no server setup to do. Set *Max Players* in Game Settings (12 is recommended).

---

## 11. Verification (what was checked, and how)

The cloud machine that built Blockfire can't run Roblox Studio, so everything was verified with automated tools instead (`tools/verify.sh`):

| Check | What it proves |
|---|---|
| **Selene lint** (Roblox globals) | No undefined variables, unused code or shadowing mistakes in all 45 scripts |
| **Roblox API check** against Roblox's official API dump | Every `Enum.X.Y`, `Instance.new` class, `GetService` name, method call and event exists and isn't deprecated. For example, it caught `Enum.Material.CorrugatedSteel`, which doesn't exist, and old `LoadCharacter` calls (the game now uses `LoadCharacterAsync`). |
| **11 unit tests** | Weapon balance (damage, falloff, sniper one-shots, time-to-kill between 0.15 and 0.6 s), level curve, springs, signals, every gun model building in every mode and camo |
| **Client smoke test** (18 checks) | The real client runs against a simulated engine that uses Roblox's own reflection data, so every UI property name and type is validated. It plays through the menu, profile, ready-up, spawn, viewmodel, auto-fire with hits, ADS zoom, reload, weapon swap, quick knife, grenade, crouch, all server feedback events, the Gun Game forced loadout and sniper scope, the in-game menu, death and death cam, the results and vote screen, and the FFA and Gun Game HUD. |
| **Server simulations** (12 checks × 4 modes) | The real server plays full matches of TDM, Domination, FFA and Gun Game. It covers joining, teams, bot filling, spawning with weapons, server-validated kills, anti-cheat rejections (spoofed origin, fake hit position, too many pellets, junk payloads), grenades, match end, voting and the next match, and players leaving. |
| **Map check** | All 36 spawn points and 50 bot nodes have room and a floor. There are 0 sightlines into team spawns. A walkability flood-fill proves both spawns can reach every flag, the enemy spawn, every FFA spawn and every bot node. |
| **Place check** | `Blockfire.rbxl` opens and contains every script (all sources compile as Luau), the map, lighting and the right service settings. |
| **Roblox source check** | The recoil and slide systems rely on how Roblox's own PlayerModule works. This was confirmed by reading Roblox's actual camera and control scripts: the camera reads `CurrentCamera.CFrame.LookVector` each frame, and controls run at `RenderPriority.Input`. |

Bugs these checks found and fixed during development:
* Vote screen offering only 2 modes.
* Engine-only properties being read before they were set.
* Spawn points blocked by props.
* Bot nodes placed inside containers.
* A sniper sightline into the spawn from the crane catwalk.
* The client not noticing when the server removed its character between matches.
