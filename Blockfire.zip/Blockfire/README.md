# BLOCKFIRE: a fast Roblox FPS

![Blockfire](docs/store/thumbnail_1.png)

**Blockfire** is a complete first-person shooter for Roblox:
- 4 game modes: Team Deathmatch, Domination, Free For All and Gun Game.
- 11 weapons plus grenades, sliding and slide-jumping, and smooth aim-down-sights.
- XP levels, weapon unlocks and camos, all saved.
- AI bots, so the game is fun even when the server is empty.
- The **Dockyard** map.
- Works on PC, phone, tablet and console.

You don't need to install anything except **Roblox Studio**.

---

## Part 1: Open the game (2 minutes)

1. Copy **`Blockfire.rbxl`** (in this folder) to the computer that has Roblox Studio.
2. **Double-click `Blockfire.rbxl`.** It opens in Roblox Studio.
   *(Or open Roblox Studio, choose **File → Open from File…** and pick `Blockfire.rbxl`.)*
3. Wait a few seconds. You will see the Dockyard map: containers, a big yellow crane and the sea.

## Part 2: Try it (2 minutes, optional but recommended)

1. Press **F5** (or click **Play** at the top of Studio).
2. The menu appears. Pick your guns, then click **READY UP** / **PLAY**.
3. After the short countdown the match starts. Bots join both teams automatically.
4. Press **Shift + F5** (or **Stop**) when you're done.

> Want to test with 2 players on one computer? Go to the **Test** tab → choose **2 players** → click **Start**.

## Part 3: Publish it to Roblox (5 minutes)

1. In Studio click **File → Publish to Roblox As…**
2. Choose **Create new experience**. Name it **Blockfire**, set the genre to **Shooter**, then click **Create**.
3. Wait for the "Published" message. Your game is now saved on Roblox, but it is still **private**.
4. Make it public:
   1. Go to **create.roblox.com** → **Creations**.
   2. Open your Blockfire experience.
   3. Fill in **Audience → Maturity & Compliance** (the questionnaire), then submit. Answer honestly: the game has cartoon gun violence, no blood and no gore.
   4. Back on **Creations**, click the **⋯** on Blockfire → **Make Public**.
5. **Optional, recommended:** upload the ready-made pictures from `docs/store/` (`icon.png`, `thumbnail_1.png`, `thumbnail_2.png`). Do it in Studio under **File → Game Settings → Basic Info**, or on the website.

**Done!** Anyone on Roblox can now find and play your game.

---

## Servers: they are FREE and automatic

You don't set up any servers. **Roblox hosts every game for free.** When people press Play, Roblox automatically starts as many servers as needed and puts players into them. Empty spots are filled with bots (see `Bots.FillTo` below).

Optional: set how many players fit in one server. We recommend **12**. You'll find it on create.roblox.com → your experience → **Places** → the place → **Server size / Max players**.

## Saving progress

XP, levels, unlocks, camos, loadouts and settings save automatically in the published game. Studio tests don't save unless you turn on **File → Game Settings → Security → Enable Studio Access to API Services**. You'll see a small note in the menu when saving is off.

---

## Controls

| Action | PC | Controller | Phone / tablet |
|---|---|---|---|
| Shoot | Left mouse | RT | FIRE (drag it to aim while shooting) |
| Aim down sights | Right mouse | LT | AIM |
| Reload | R | X | R |
| Sprint | Left Shift | L3 (click left stick) | RUN |
| Crouch / Slide (crouch while sprinting) | C or Ctrl | B | CROUCH |
| Jump (jump during a slide to slide-jump) | Space | A | Jump button |
| Switch weapon | 1 / 2 / 3, mouse wheel, Q = last weapon | Y | SWAP |
| Grenade | G | RB | NADE |
| Quick knife | V or F | R3 | KNIFE |
| Scoreboard | Tab (hold) | D-pad down (hold) | TAB |
| Loadout & settings while playing | M | D-pad up | ☰ |
| Deploy from the menu | Space or click DEPLOY | A on DEPLOY | DEPLOY |

## Game modes

| Mode | How to win |
|---|---|
| **Team Deathmatch** | First team to 40 kills |
| **Domination** | Capture flags A, B and C. Each flag you hold scores points. First to 150 wins. |
| **Free For All** | First player to 20 kills |
| **Gun Game** | Every kill gives you the next gun. Win by getting a kill with the final weapon, the knife. Getting knifed sends you back a level! |

At the end of every match, everyone votes for the next mode.

---

## Easy changes (no coding skills needed)

In Studio, open the **Explorer** window (View → Explorer), then go to **ReplicatedStorage → Blockfire → Config** and double-click a file:

- **GameConfig**: the main settings.
  - `Bots.Enabled = false` turns bots off.
  - `Bots.FillTo = 10` sets how many fighters a server is filled up to.
  - `Bots.AimError` changes how well bots aim (bigger = worse aim).
  - You can also change health, respawn time, walk/sprint speed and the intermission or results times.
- **Modes**: time limits and score limits for each mode.
- **Weapons**: damage, fire rate, magazine size, recoil and unlock levels for every gun.
- **Progression**: XP rewards, the level curve and camo requirements.
- **Sounds**: all game sounds. The defaults are classic sounds built into Roblox.
  - **Better gun sounds:** open **Toolbox → Audio**, search e.g. "rifle shot", right-click a sound → **Copy Asset ID**.
  - Then put `"rbxassetid://THE_NUMBER"` as the **first** entry in that sound's `Ids` list.

**Editing the map:** it's in **Workspace → Map**. Move, add or delete parts as you like. Just keep these folders:
- `Spawns`: spawn points, each with a `Team` attribute of Blue, Red or FFA.
- `Objectives`: the A/B/C flags.
- `BotNodes`: spots bots like to walk to.
- `Barriers`: invisible map edges.
- `Water`: the blue boxes that become real water when the game runs.

After changing anything, press **F5** to test, then **File → Publish to Roblox** to update the live game.

## Troubleshooting

- **Something doesn't work in a test:** open **View → Output** and look for red text that starts with `[Blockfire]`. It tells you which part failed.
- **No sound from guns:** some built-in sounds may not exist on every device. Replace them with Toolbox sounds as explained above.
- **Game feels laggy on old phones:** lower `Bots.FillTo` in GameConfig.
- **Crouch looks odd for some players:** the crouch pose is made for R15 avatars. Set **Game Settings → Avatar** to **R15** (recommended).

---

## What's inside this folder

| Path | What it is |
|---|---|
| `Blockfire.rbxl` | **The game. Open this in Roblox Studio.** |
| `docs/GAME_DESIGN.md` | Full game design: modes, weapons, map, systems |
| `docs/store/` | Ready-made game icon and thumbnails |
| `docs/screenshots/` | Preview pictures of the map and weapons |
| `src/` | All game code (it is already inside `Blockfire.rbxl`) |
| `tools/`, `tests/` | Map generator, build and automated test tools (for programmers) |

### For programmers (optional)

The project uses a [Rojo](https://rojo.space) layout. `default.project.json` maps `src/` into the place:
- `src/shared` → ReplicatedStorage.Blockfire
- `src/server` → ServerScriptService.BlockfireServer
- `src/client` → StarterPlayerScripts.BlockfireClient

You can also live-sync the code into Studio with the Rojo plugin (`rojo serve`).

- `tools/build.sh`: regenerates the map and rebuilds `Blockfire.rbxl`. Needs [Lune](https://lune-org.github.io/docs) and Rojo.
- `tools/verify.sh`: runs every automated check:
  - Selene lint.
  - A check of every enum, class, service, method and event against the official Roblox API.
  - Unit tests.
  - A client test that boots the real client and plays through menu → spawn → shoot → die → results.
  - Server simulations that play full matches of all 4 modes with bots, validated hits and anti-cheat rejections.
  - A map check covering spawn safety, sightlines into spawns and walkability.

**How it was verified:** all of the checks above pass. They run the real game code against Roblox's official API data and a simulated engine. They can't replace a real Roblox Studio session, so do the quick test in Part 2 before publishing.
